 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os, time


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]

        group = "Fixpunktekategorie3" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"

        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)

        try:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Toleranzstufen"
            layer["readonly"] = True 
            layer["featuretype"] = "tseinteilung_toleranzstufe"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "tseinteilung/toleranzstufe_"+_locale+".qml"
            vlayerToleranzstufe = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings, False,  False)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"HFP3 Nachführung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie3_hfp3nachfuehrung"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            vlayerHFP3NF = self.layerLoader.load(layer)            

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "HFP3"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie3_hfp3"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "fixpunkte/hfp2_"+_locale+".qml"
            vlayerHFP3 = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"LFP3 Nachführung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie3_lfp3nachfuehrung"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            vlayerLFP3NF = self.layerLoader.load(layer)     

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP3"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie3_lfp3"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "fixpunkte/lfp3_"+_locale+".qml"
            vlayerLFP3 = self.layerLoader.load(layer)
         
   
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u'LFP3 nicht zuverlässig'
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie3_lfp3"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "lagezuv_txt = 'nein'"
            layer["group"] = group
            layer["style"] = "fixpunkte/lfp3nichtzuverlaessig_"+_locale+".qml"
            vlayerLFP3nichtzuverlaessig = self.layerLoader.load(layer) 
            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP3 Genauigkeitsverteilung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie3_lfp3"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "fixpunkte/lfp3genauigkeitsverteilung_"+_locale+".qml"
            vlayerLFP3genauigkeit = self.layerLoader.load(layer)    
            
#            layer = {}
#            layer["type"] = "wms"
#            layer["url"] = "http://wms.geo.admin.ch/"
#            layer["layers"] = "ch.swisstopo.fixpunkte-lage-lfp1,ch.swisstopo.fixpunkte-lage-lfp2,ch.swisstopo.fixpunkte-lage-lv95"
#            layer["crs"] = "EPSG:21781"
#            layer["format"] = "image/png"
#            layer["title"] = "Lagefixpunkte"
#            layer["group"] = "Fixpunktekategorie2"
#            vlayerLFPWMS = self.layerLoader.load(layer)
#            
#            layer = {}
#            layer["type"] = "wms"
#            layer["url"] = "http://wms.geo.admin.ch/"
#            layer["layers"] = "ch.swisstopo.fixpunkte-hoehe-hfp1,ch.swisstopo.fixpunkte-hoehe-hfp2"
#            layer["crs"] = "EPSG:21781"
#            layer["format"] = "image/png"
#            layer["title"] = u"Höhenfixpunkte"
#            layer["group"] = "Fixpunktekategorie2"
#            vlayerHFPWMS = self.layerLoader.load(layer)            

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Gemeindegrenze"
            layer["readonly"] = True 
            layer["featuretype"] = "gemeindegrenzen_gemeindegrenze"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "gemeindegrenze/gemeindegrenze_"+_locale+".qml"           
            vlayerGemeinde = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  True)
         
         
            QApplication.restoreOverrideCursor()

            lfp3nichtzuverlaessig = vlayerLFP3nichtzuverlaessig.featureCount()
            


            QMessageBox.information( None, "Statistik Fixpunkte", "<b>Statistik Fixpunkte:</b> <br>" 
                                    + "<table>" 
                                    + "<tr> <td>LFP3 "+ u'nicht zuverlässig' + ": </td> <td>" + str(lfp3nichtzuverlaessig) +  "</td> </tr>"                                     
                                    + "</table>")

        except:        
            QApplication.restoreOverrideCursor()
