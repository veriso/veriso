 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = u"Verkehrs- + Gewässernetz" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {}

          layer["title"] = "Gewässernetz (BB)"
          layer["readonly"] = True
          layer["featuretype"] = "bodenbedeckung_boflaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["sql"] = "art in (14,15,16)"
          layer["style"] = "bodenbedeckung/gewaesser_"+_locale+".qml"
          vlayerGewae = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False) 
          layer = {}

          layer["title"] = "Verkehrsnetz (BB)"
          layer["readonly"] = True
          layer["featuretype"] = "bodenbedeckung_boflaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = "art in (1,2,3,4)"
          layer["style"] = "bodenbedeckung/verkehr_"+_locale+".qml"
          vlayerVerkehr = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "EO-Flächenelemente (Netz)"
          layer["readonly"] = True
          layer["featuretype"] = "z_eo_flaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ctid"
          layer["sql"] = "art in (3,5,6,7,17,18,22,25,26,29,34,36)"
          layer["style"] = "bodenbedeckung/eo_verkehr_"+_locale+".qml"
          vlayerEOFl = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "EO-Linienelemente (Netz)"
          layer["readonly"] = True
          layer["featuretype"] = "z_eo_linie"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ctid"
          layer["sql"] = "art in (3,5,6,7,17,18,22,25,26,29,34,36)"
          layer["style"] = "bodenbedeckung/eo_linie_verkehr_"+_locale+".qml"
          vlayerEOLinie = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "EO-Punkt"
          layer["readonly"] = True
          layer["featuretype"] = "z_eo_punkt"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ctid"
          layer["sql"] = ""
          layer["style"] = "bodenbedeckung/eo_punk_"+_locale+".qml"
          vlayerEOPkt = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

