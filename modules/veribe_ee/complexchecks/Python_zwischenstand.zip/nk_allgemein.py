 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = "Flurnamen" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {}

          layer["title"] = "Liegenschaften"
          layer["readonly"] = True
          layer["featuretype"] = "liegenschaften_liegenschaft"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/liegenschaft_"+_locale+".qml"
          vlayerLS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "SDR"
          layer["readonly"] = True
          layer["featuretype"] = "liegenschaften_selbstrecht"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/selbstrecht_"+_locale+".qml"
          vlayerSDR = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "proj. Liegenschaften"
          layer["readonly"] = True
          layer["featuretype"] = "liegenschaften_projliegenschaft"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/projliegenschaft_"+_locale+".qml"
          vlayerprojLS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "proj. SDR"
          layer["readonly"] = True
          layer["featuretype"] = "liegenschaften_projselbstrecht"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/projselbstrecht_"+_locale+".qml"
          vlayerprojSDR = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Grst-Nr"
          layer["readonly"] = True
          layer["featuretype"] = "z_gs_nr"
          layer["geom"] = "pos"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/GS_NR_"+_locale+".qml"
          vlayerGSNR = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)	
          layer = {}

          layer["title"] = "proj Grst-Nr"
          layer["readonly"] = True
          layer["featuretype"] = "z_projgs_nr"
          layer["geom"] = "pos"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/proj_GS_NR_"+_locale+".qml"
          vlayerprojGSNR = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)

          layer = {}

          layer["title"] = "Flurnamen"
          layer["readonly"] = True
          layer["featuretype"] = "nomenklatur_flurname"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "nomenklatur/nomenklatur_"+_locale+".qml"
          vlayerFlurname = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)


        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

