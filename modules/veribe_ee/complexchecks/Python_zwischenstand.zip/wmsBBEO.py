 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = u"WMS BB, EO" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {} 
          layer["type"] = "wms"
          layer["group"] = group
          layer["title"] = "gesch. geol. Objekte"
          layer["url"] ="http://www.geoservice.apps.be.ch/geoservice/services/a4p/a4p_geologiewms_d_fk_s/MapServer/WMSServer?"
          layer["layers"] ="GEODB.GGO_GGOP"
          layer["format"] ="image/png"
          layer["crs"] ="EPSG:21781"
          layer["sql"] = ""
          layer["style"] = ""
          vlayerGGO = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {} 
          layer["type"] = "wms"
          layer["group"] = group
          layer["title"] = "Lawinienverb."
          layer["url"] ="http://www.geoservice.apps.be.ch/geoservice/services/a4p/a4p_umweltwms_d_fk_s/MapServer/WMSServer?"
          layer["layers"] ="GEODB.SCHBLAW_SBLAWP,GEODB.SCHBLAW_SBLAW"
          layer["format"] ="image/png"
          layer["crs"] ="EPSG:21781"
          layer["sql"] = ""
          layer["style"] = ""
          vlayerLawine = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {} 
          layer["type"] = "wms"
          layer["group"] = group
          layer["title"] = "GBO (geschuetzte botanische...)"
          layer["url"] ="http://www.geoservice.apps.be.ch/geoservice/services/a4p/a4p_umweltwms_d_fk_s/MapServer/WMSServer?"
          layer["layers"] ="GEODB.GBO_GBOP,GEODB.GBO_GBOF"
          layer["format"] ="image/png"
          layer["crs"] ="EPSG:21781"
          layer["sql"] = ""
          layer["style"] = ""
          vlayerGBO = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {} 
          layer["type"] = "wms"
          layer["group"] = group
          layer["title"] = "GN5"
          layer["url"] ="http://www.geoservice.apps.be.ch/geoservice/services/a4p/a4p_gewaesserwms_d_fk_s/MapServer/WMSServer?"
          layer["layers"] ="GEODB.GN5_GN5ROUTE_B,GEODB.GN5_DOLUNG,GEODB.GN5_GN5ROUTE"
          layer["format"] ="image/png"
          layer["crs"] ="EPSG:21781"
          layer["sql"] = ""
          layer["style"] = ""
          vlayerGN5 = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {} 
          layer["type"] = "wms"
          layer["group"] = group
          layer["title"] = "Wanderwege"
          layer["url"] ="http://www.geoservice.apps.be.ch/geoservice/services/a4p/a4p_transportwms_d_fk_s/MapServer/WMSServer?"
          layer["layers"] ="GEODB.WANDERN_WEGNETZ"
          layer["format"] ="image/png"
          layer["crs"] ="EPSG:21781"
          layer["sql"] = ""
          layer["style"] = ""
          vlayerWander = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
 
        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

