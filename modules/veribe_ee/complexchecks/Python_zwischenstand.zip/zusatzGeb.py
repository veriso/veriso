 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = u"Zusatz Gebäude" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {}
    
          layer["title"] = "BEGID (EO)"
          layer["readonly"] = True
          layer["featuretype"] = "z_objektnummer_pos"
          layer["key"] = "ogc_fid"
          layer["geom"] = "pos"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/BEGIDeo_"+_locale+".qml"
          vlayerBEGIDeo = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "BEGID (BB)"
          layer["readonly"] = True
          layer["featuretype"] = "z_gebaeudenummer_pos"
          layer["key"] = "ogc_fid"
          layer["geom"] = "pos"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/BEGIDbb_"+_locale+".qml"
          vlayerBEGISBB = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)

          layer = {}
    
          layer["title"] = "Strassenstueck zwischen Ortschaften"
          layer["readonly"] = True
          layer["featuretype"] = "z_Geb_Strassen_Ortschaft"
          layer["key"] = "ogc_fid"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/Strassen_Ortschaft_"+_locale+".qml"
          vlayerOrtstr = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "benanntes Gebiet zwischen Ortschaften"
          layer["readonly"] = True
          layer["featuretype"] = "z_benGeb_Ortschaft"
          layer["key"] = "ogc_fid"
          layer["geom"] = "flaeche"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/benGeb_Ortschaft_"+_locale+".qml"
          vlayerbenGebOrt = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "Gebaeudeeinang Status"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_gebaeudeeingang"
          layer["key"] = "ogc_fid"
          layer["geom"] = "lage"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/status_GE_"+_locale+".qml"
          vlayerGebStat = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False) 
          layer = {}
    
          layer["title"] = "Gebaeudeeinang provisorisch"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_gebaeudeeingang"
          layer["key"] = "ogc_fid"
          layer["geom"] = "lage"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/prov_GE_"+_locale+".qml"
          vlayerGebprov = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False) 
          layer = {}
    
          layer["title"] = "Gebaeudeeinang in Aenderung"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_gebaeudeeingang"
          layer["key"] = "ogc_fid"
          layer["geom"] = "lage"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/aendern_GE_"+_locale+".qml"
          vlayerGebMut = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False) 


        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

