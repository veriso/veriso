 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group = "unvollstaendig / streitig" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "streitige Liegenschaften"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_liegenschaft_v2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Gueltigkeit=1"            
            layer["group"] = group
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerstreitigLS = self.layerLoader.load(layer)
 
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"unvollstaendige Liegenschaften"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_liegenschaft_v2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Vollstaendigkeit=1"
            layer["group"] = group
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerunvollLS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  True)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "streitige SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_selbstrecht_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Gueltigkeit=1"
            layer["group"] = group
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerstreitigSDR = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"unvollstaendige SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_selbstrecht_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Vollstaendigkeit=1"
            layer["group"] = group
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerunvollSDR = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Linienart unvollstaendige SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "z_lineatt_sdr"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Linienart is NULL"
            layer["group"] = group
            layer["style"] = "liegenschaften/voll_streitig_"+_locale+".qml"
            vlayerLunvollSDR = self.layerLoader.load(layer)

#            layer = {}
 #           layer["type"] = "postgres"
  #          layer["title"] = "Linienart streitig SDR"
   #         layer["readonly"] = True 
    #        layer["featuretype"] = "z_lineatt_sdr"
     #       layer["geom"] = "geometrie"
      #      layer["key"] = "ogc_fid"            
       #     layer["sql"] = "Linienart is NULL"
        #    layer["group"] = group
         #   layer["style"] = "liegenschaften/voll_streitig_"+_locale+".qml"
          #  vlayerLstreitigSDR = self.layerLoader.load(layer)

#            layer = {}
 #           layer["type"] = "postgres"
  #          layer["title"] = "Linienart streitig LS"
   #         layer["readonly"] = True 
    #        layer["featuretype"] = "z_lineatt_ls"
     #       layer["geom"] = "geometrie"
      #      layer["key"] = "ogc_fid"            
       #     layer["sql"] = "linienart is NULL"
        #    layer["group"] = group
         #   layer["style"] = "liegenschaften/voll_streitig_"+_locale+".qml"
          #  vlayerLstreitigLS = self.layerLoader.load(layer)

#            layer = {}
 #           layer["type"] = "postgres"
  #          layer["title"] = "Linienart unvollstaendig LS"
   #         layer["readonly"] = True 
    #        layer["featuretype"] = "z_lineatt_ls"
     #       layer["geom"] = "geometrie"
      #      layer["key"] = "ogc_fid"            
       #     layer["sql"] = "linienart is NULL"
        #    layer["group"] = group
         #   layer["style"] = "liegenschaften/voll_streitig_"+_locale+".qml"
          #  vlayerLstreitigLS = self.layerLoader.load(layer)

            streitigLS = vlayerstreitigLS.featureCount()
            streitigSDR = vlayerstreitigSDR.featureCount()
            unvollLS = vlayerunvollLS.featureCount()
            unvollSDR = vlayerunvollSDR.featureCount()
#            LunvollSDR = vlayerLunvollSDR.featureCount()
 #           LstreitigSDR = vlayerstreitigSDR.featureCount()
  #          LunvollLS = vlayerLunvollLS.featureCount()
   #         LstreitigLS = vlayerstreitigLS.featureCount()


            QMessageBox.information( None, "Vollstaendigkeit / Gueltigkeit", "<b>Vollstaendigkeit / Gueltigkeit</b> <br>" 
                                    + "<table>" 
				    + "<tr> <td>streitige LS: </td> <td>" + str(streitigLS) +  "</td> </tr>"
                                    + "<tr> <td>unvollstaendige LS: </td> <td>" + str(unvollLS) +  "</td> </tr>"                                + "<tr> <td>streitige SDR: </td> <td>" + str(streitigSDR) +  "</td> </tr>"                                + "<tr> <td>unvollstaendige SDR: </td> <td>" + str(unvollSDR) +  "</td> </tr>"  
#+ "<tr> <td>Linie unvoll. SDR: </td> <td>" + str(LunvollSDR) +  "</td> </tr>" 
#+ "<tr> <td>Linie unvoll. LS: </td> <td>" + str(LunvollLS) +  "</td> </tr>" 
# + "<tr> <td>Linie streitige SDR: </td> <td>" + str(LstreitigSDR) +  "</td></tr>"
# + "<tr> <td>Linie streitige LS: </td> <td>" + str(LstreitigLS) +  "</td></tr>"
                                    + "</table>")

        except:        
            QApplication.restoreOverrideCursor()
 
        QApplication.restoreOverrideCursor()       



#        eingangOhneLokalisation = vlayerEingangOhneLokalisation.featureCount()
#        lokalisationsNameOhneEingang = vlayerLokalisationsNameOhneEingang.featureCount()
#        strassenstueckLinieIstAchse = vlayerStrassenstueckLinieIstAchse.featureCount()
#
#        QMessageBox.information( None, "Statistik Einzelobjekte", "<b>Statistik Einzelobjekte:</b> <br>" 
#                                + "<table>" 
#                                + u"<tr> <td>Mast_Leitung als Fläche: </td> <td>" + str(mastLeitungFlaeche) +  "</td> </tr>" 
#                                + u"<tr> <td>schmaler_Weg als Fläche: </td> <td>" + str(schmalerWegFlaeche) +  "</td> </tr>" 
#                                + "<tr> <td>Fahrspur als Linie: </td> <td>" + str(fahrspurLinie) +  "</td> </tr>" 
#                                + "</table>")
