 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = "Adressen-Spinnennetz" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {}
    
          layer["title"] = "Ortschaften"
          layer["readonly"] = True
          layer["featuretype"] = "z_ortschaftsnamen_geom"
          layer["geom"] = "flaeche"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/ortschaft_"+_locale+".qml"
          vlayerOrt = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "PLZ"
          layer["readonly"] = True
          layer["featuretype"] = "plzortschaft_plz6"
          layer["geom"] = "flaeche"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/plz_"+_locale+".qml"
          vlayerPLZ = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "benanntes Gebiet"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_benanntesgebiet"
          layer["geom"] = "flaeche"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/benanntesGebiet_"+_locale+".qml"
          vlayerbenGeb = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "BoFlaeche"
          layer["readonly"] = True
          layer["featuretype"] = "bodenbedeckung_boflaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = "art = 0 OR art = 1 OR art = 2"
          layer["style"] = "bodenbedeckung/gebaeude_strassen_trottoir_"+_locale+".qml"
          vlayerBB = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)

          layer = {}
          layer["title"] = "proj. Gebaeude"
          layer["readonly"] = True
          layer["featuretype"] = "bodenbedeckung_projboflaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = "art = 0"
          layer["style"] = "bodenbedeckung/projGebaeude_"+_locale+".qml"
          vlayerprojGeb = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "adressierbare EOs"
          layer["readonly"] = True
          layer["featuretype"] = "z_eo_flaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ctid"
          layer["sql"] = "art in (1,2,6,9,11,16,21)"
          layer["style"] = "gebaeudeadressen/EO_Gebaeude_"+_locale+".qml"
          vlayeradressEO = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "Strassenstueck Anfangspunkt"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_strassenstueck"
          layer["geom"] = "anfangspunkt"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/Anfangspunkt_"+_locale+".qml"
          vlayerStrasseA = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "Strassenstueck (Geometrie)"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_strassenstueck"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["sql"] = ""
          layer["key"] = "ogc_fid"
          layer["style"] = "gebaeudeadressen/strassenachsen_Pfeil_"+_locale+".qml"
          vlayerStrasse = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}
    
          layer["title"] = "Spinnennetz"
          layer["readonly"] = True
          layer["featuretype"] = "spiderweb_v"
          layer["geom"] = "line"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "gebaeudeadressen/spinnennetz_blau_"+_locale+".qml"
          vlayerSpinne = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)    
          layer = {}
    
          layer["title"] = "Gebaeudeeingang BB/EO"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_gebaeudeeingang"
          layer["geom"] = "lage"
          layer["group"] = group
          layer["sql"] = ""
          layer["key"] = "ogc_fid"
          layer["style"] = "gebaeudeadressen/GebEingang_BB_EO_"+_locale+".qml"
          vlayerEingang = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)    
          layer = {}
    
          layer["title"] = "LokalisationsNamePos"
          layer["readonly"] = True
          layer["featuretype"] = "gebaeudeadressen_lokalisationsnamepos_v"
          layer["geom"] = "pos"
          layer["group"] = group
          layer["sql"] = ""
          layer["key"] = "ogc_fid"
          layer["style"] = "gebaeudeadressen/lokalisationsnamepos_"+_locale+".qml"
          vlayerLokNamPos = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)        


        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

