 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = "Planeinteilung" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {}

          layer["title"] = "Gemeinde"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_gemeindegrenze"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "planeinteilung/gemeinde_"+_locale+".qml"
          vlayerGemeinde = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Bodenbedeckungskanten"
          layer["readonly"] = True
          layer["featuretype"] = "bodenbedeckung_boflaeche"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "planeinteilung/bbkanten_"+_locale+".qml"
          vlayerBBkante = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Liegenschaften"
          layer["readonly"] = True
          layer["featuretype"] = "liegenschaften_liegenschaft"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "planeinteilung/liegenschaften_"+_locale+".qml"
          vlayerLS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Planeinteilung"
          layer["readonly"] = True
          layer["featuretype"] = "planeinteilungen_plan_v"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "planeinteilung/plan_"+_locale+".qml"
          vlayerPlan = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Plan-Nr. Pos"
          layer["readonly"] = True
          layer["featuretype"] = "planeinteilungen_planpos"
          layer["geom"] = "pos"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "planeinteilung/nr_pos_"+_locale+".qml"
          vlayerPlanPos = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)



        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

