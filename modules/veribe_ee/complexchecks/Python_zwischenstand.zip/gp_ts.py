# -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group = "Grenzpunkte" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "GP unversichert"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_grenzpunkt"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "punktzeichen=6"
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_unver_"+_locale+".qml"
            vlayerunvGP = self.layerLoader.load(layer)
            unvGP = vlayerunvGP.featureCount()

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "GP nicht exakt definiert"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_grenzpunkt"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "exaktdefiniert=1"
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_exakt_"+_locale+".qml"
            vlayerunex = self.layerLoader.load(layer)
            unex = vlayerunex.featureCount()

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "GP unzuv"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_grenzpunkt"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "lagezuv=1"
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_zuv_"+_locale+".qml"
            vlayerunzuv = self.layerLoader.load(layer)
            unzuv = vlayerunzuv.featureCount()

            layer["type"] = "postgres"
            layer["title"] = "GP zuv"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_grenzpunkt"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "lagezuv=0"
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_zuv_"+_locale+".qml"
            vlayerzuv = self.layerLoader.load(layer)
            zuv = vlayerzuv.featureCount()

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "GP Genauigkeit"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_grenzpunkt"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_gen_"+_locale+".qml"
            vlayergenGP = self.layerLoader.load(layer)
            genGP = vlayergenGP.featureCount()

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "SDR Qualitaet"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_selbstrecht"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/ls_quali_"+_locale+".qml"
            vlayersdr = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Liegenschaften Qualitaet"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_liegenschaft"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/ls_quali_"+_locale+".qml"
            vlayerLS = self.layerLoader.load(layer)  

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "proj SDR Qualitaet"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_projselbstrecht"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/q_proj_ls_"+_locale+".qml"
            vlayerprojsdr = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "proj Liegenschaften Qualitaet"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_projliegenschaft"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/q_proj_ls_"+_locale+".qml"
            vlayerprojLS = self.layerLoader.load(layer) 


            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "GP-Genauigkeiten schlechter AV93-Qalitaet"
            layer["readonly"] = True 
            layer["featuretype"] = "z_v_gp_ts"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "(exaktdefiniert = 0 AND ((art <2  AND lagegen  > 5) OR (art = 2 AND lagegen > 7) OR (art = 3 AND lagegen > 15) OR (art = 4 AND lagegen > 35))) OR (exaktdefiniert = 1 AND ((art <2  AND lagegen  > 20) OR (art = 2 AND lagegen > 35) OR (art = 3 AND lagegen > 75) OR (art = 4 AND lagegen >  150)))"
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_TS_Gen_"+_locale+".qml"
            vlayerGP = self.layerLoader.load(layer)

            GP = vlayerGP.featureCount()


            QMessageBox.information( None, "Statistik Grenzpunkte", "<b>Statistik Grenzpunkte:</b> <br>" 
                                    + "<table>"
+ "<tr> <td>Anzahl GP's: </td> <td>" + str(genGP) +  "</td> </tr>" 

                                    + "<tr> <td>Genauigkeit schlechter AV93: </td> <td>" + str(GP) +  "</td> </tr>"    
+ "<tr> <td>unzuverlaessige GP's: </td> <td>" + str(unzuv) +  "</td> </tr>"
                                    + "<tr> <td>unversicherte GP's: </td> <td>" + str(unvGP) +  "</td> </tr>" 
+ "<tr> <td>nicht exakt definiert: </td> <td>" + str(unex) +  "</td> </tr>"
                           + "</table>")



        except:        
            QApplication.restoreOverrideCursor()
 
        QApplication.restoreOverrideCursor() 
