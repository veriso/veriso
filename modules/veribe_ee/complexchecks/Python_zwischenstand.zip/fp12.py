 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group = "Fixpunkte 1/2" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Toleranzstufen"
            layer["readonly"] = True 
            layer["featuretype"] = "tseinteilung_toleranzstufe"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "tseinteilung/toleranzstufe_"+_locale+".qml"
            vlayerGemeinde = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings, False,  False)

            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"HFP2 Nachführung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie2_hfp2nachfuehrung"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            vlayerHFP2NF = self.layerLoader.load(layer)         
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Gemeindegrenze"
            layer["readonly"] = True 
            layer["featuretype"] = "gemeindegrenzen_gemeindegrenze"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "gemeindegrenze/gemeindegrenze_"+_locale+".qml"
            vlayerGemeinde = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  True)
            
                    
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "HFP2"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie2_hfp2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            layer["style"] = "fixpunkte/hfp2_"+_locale+".qml"
            vlayerHFP2 = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"LFP2 Nachführung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie2_lfp2nachfuehrung"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            vlayerLFP2NF = self.layerLoader.load(layer)  

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP2"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie2_lfp2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            layer["style"] = "fixpunkte/lfp2_"+_locale+".qml"
            vlayerLFP2 = self.layerLoader.load(layer)
            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"HFP1 Nachführung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie1_hfp1nachfuehrung"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            vlayerHFP1NF = self.layerLoader.load(layer)            
                        
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "HFP1"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie1_hfp1"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            layer["style"] = "fixpunkte/hfp1_"+_locale+".qml"
            vlayerHFP1 = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"LFP1 Nachführung"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie1_lfp1nachfuehrung"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            vlayerLFP1NF = self.layerLoader.load(layer)     

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP1"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie1_lfp1"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group        
            layer["style"] = "fixpunkte/lfp1_"+_locale+".qml"
            vlayerLFP1 = self.layerLoader.load(layer)


            layer = {}
            layer["type"] = "wms"
            layer["url"] = "http://wms.geo.admin.ch/?"
            layer["layers"] = "ch.swisstopo.fixpunkte-hfp1"
            layer["crs"] = "EPSG:21781"
            layer["format"] = "image/png"
            layer["title"] = "Hoehenfixpunkte 1"
            layer["group"] = group
            vlayerHFPWMS = self.layerLoader.load(layer) 

            layer = {}
            layer["type"] = "wms"
            layer["url"] = "http://wms.geo.admin.ch/?"
            layer["layers"] = "ch.swisstopo.fixpunkte-hfp2"
            layer["crs"] = "EPSG:21781"
            layer["format"] = "image/png"
            layer["title"] = "Hoehenfixpunkte 2"
            layer["group"] = group
            vlayerHFPWMS = self.layerLoader.load(layer) 


            layer = {}
            layer["type"] = "wms"
            layer["url"] = "http://wms.geo.admin.ch/?"
            layer["layers"] = "ch.swisstopo.fixpunkte-lfp1"
            layer["crs"] = "EPSG:21781"
            layer["format"] = "image/png"
            layer["title"] = "Lagefixpunkte 1"
            layer["group"] = group
            vlayerLFPWMS = self.layerLoader.load(layer)
            
            layer = {}
            layer["type"] = "wms"
            layer["url"] = "http://wms.geo.admin.ch/?"
            layer["layers"] = "ch.swisstopo.fixpunkte-lfp2"
            layer["crs"] = "EPSG:21781"
            layer["format"] = "image/png"
            layer["title"] = "Lagefixpunkte 2"
            layer["group"] = group
            vlayerLFPWMS = self.layerLoader.load(layer)
            
            QApplication.restoreOverrideCursor()

            hfp1 = vlayerHFP1.featureCount()
            lfp1 = vlayerLFP1.featureCount()
            hfp2 = vlayerHFP2.featureCount()
            lfp2 = vlayerLFP2.featureCount()
            hfp1NF = vlayerHFP1NF.featureCount()
            lfp1NF = vlayerLFP1NF.featureCount()
            hfp2NF = vlayerHFP2NF.featureCount()
            lfp2NF = vlayerLFP2NF.featureCount()


            QMessageBox.information( None, "Statistik Fixpunkte", "<b>Statistik Fixpunkte 1/2:</b> <br>" 
                                    + "<table>" 
                                    + "<tr> <td>HFP1: </td> <td>" + str(hfp1) +  "</td> </tr>" 
                                    + "<tr> <td>LFP1: </td> <td>" + str(lfp1) +  "</td> </tr>" 
                                    + "<tr> <td>HFP2: </td> <td>" + str(hfp2) +  "</td> </tr>" 
                                    + "<tr> <td>LFP2: </td> <td>" + str(lfp2) +  "</td> </tr>" 
                                    + "<tr> <td>NF-Anzahl HFP1: </td> <td>" + str(hfp1NF) +  "</td> </tr>" 
                                    + "<tr> <td>NF-Anzahl LFP1: </td> <td>" + str(lfp1NF) +  "</td> </tr>" 
                                    + "<tr> <td>NF-Anzahl HFP2: </td> <td>" + str(hfp2NF) +  "</td> </tr>" 
                                    + "<tr> <td>NF-Anzahl LFP2: </td> <td>" + str(lfp2NF) +  "</td> </tr>"
                                    + "</table>")

        except:        
            QApplication.restoreOverrideCursor()
