 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os, time


class ComplexCheck( QObject ):
    
    def __init__( self,  iface, settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        
        
    def run(self):
        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        # Falls Gebaeudeadressen - Lokalisationstest Gruppe nicht vorhanden ist
        # muss sie zuerst hinzugefuegt werden.
        
        group = "Gebaeudeadressen - Lokalisationstest" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"
        
        # Zu guter Letzt brauchen wir auch noch die Tabelle Lokalisation
        vlayerLokalisation = soverify.tools.utils.getVectorLayerByName("Lokalisation Lokalisationstest")
        if vlayerLokalisation == None:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Lokalisation Lokalisationstest"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_lokalisation"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"            
            layer["sql"] = "tid = '-1'"
            layer["group"] = group
            vlayerLokalisation = self.layerLoader.load(layer)                             
            
        # Strassenstuecke (geometrie) und (anfangspunkt) und Benanntes Gebiet und Eingänge suchen.
        vlayerStrassenstueckLinie = soverify.tools.utils.getVectorLayerByName("Strassenstueck (geometrie) Lokalisationstest")
        if vlayerStrassenstueckLinie == None:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Strassenstueck (geometrie) Lokalisationstest"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_strassenstueck"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "strassenstueck_von = '-1'"
            layer["group"] = group
            layer["style"] = "gebaeudeadressen/strassenachsen_rot_"+_locale+".qml"
            vlayerStrassenstueckLinie = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  False)

        vlayerStrassenstueckAnfangspunkt = soverify.tools.utils.getVectorLayerByName("Strassenstueck (anfangspunkt) Lokalisationstest")
        if vlayerStrassenstueckAnfangspunkt == None:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Strassenstueck (anfangspunkt) Lokalisationstest"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_strassenstueck"
            layer["geom"] = "anfangspunkt"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "strassenstueck_von = '-1'"
            layer["group"] = group
            layer["style"] = "gebaeudeadressen/anfangspunkt_rot_"+_locale+".qml"
            vlayerStrassenstueckAnfangspunkt = self.layerLoader.load(layer)
            
        vlayerBenanntesGebiet = soverify.tools.utils.getVectorLayerByName("Benanntes Gebiet Lokalisationstest")
        if vlayerBenanntesGebiet == None:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Benanntes Gebiet Lokalisationstest"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_benanntesgebiet"
            layer["geom"] = "flaeche"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "benanntesgebiet_von = '-1'"
            layer["group"] = group
            layer["style"] = "gebaeudeadressen/benanntesgebiet_rot_"+_locale+".qml"
            vlayerBenanntesGebiet= self.layerLoader.load(layer)                 
  
        vlayerEingaenge = soverify.tools.utils.getVectorLayerByName("Gebaeudeeingang Lokalisationstest")
        if vlayerEingaenge == None:
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Gebaeudeeingang Lokalisationstest"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_gebaeudeeingang"
            layer["geom"] = "lage"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "gebaeudeeingang_von = '-1'"
            layer["group"] = group
            layer["style"] = "gebaeudeadressen/gebaeudeeingang_rot_"+_locale+".qml"
            vlayerEingaenge = self.layerLoader.load(layer)
   
        # LokalisationsName-Layer suchen. Dieser muss bereits vorhanden sein, 
        # da dort was selektiert sein muss.
        vlayerLokalisationsName = soverify.tools.utils.getVectorLayerByName("LokalisationsName")
        if vlayerLokalisationsName == None:
            QMessageBox.warning( None, "", "LokalisationsName nicht gefunden.")
            return         
            
        # Eine Liste mit allen IDs erstellen.
        provider = vlayerLokalisationsName.dataProvider()
        feat = QgsFeature()
        allAttrs = provider.attributeIndexes()
        provider.select(allAttrs, QgsRectangle(), False, False)

        # Wie kann ich verhindern, dass das jedesmal ausgeführt wird?
        # Klasse wird jedesmal neu initialisert....
        ids = []
        while provider.nextFeature(feat):
            ids.append(feat.id())
            
        
        # Es darf nur ein Feature selektiert sein.
        if vlayerLokalisationsName.selectedFeatureCount() < 1:
            QMessageBox.warning( None, "", "Keine Strasse selektiert.")
            return
            
        if vlayerLokalisationsName.selectedFeatureCount() > 1:
            QMessageBox.warning( None, "", "Nur eine Strasse selektieren.")
            return
            
        id = vlayerLokalisationsName.selectedFeaturesIds()[0]
        idx = ids.index(id)
        
        # Selektiertes Feature.
        feat = QgsFeature()
        vlayerLokalisationsName.featureAtId(id, feat, False)
        
        benannteIdx = provider.fieldNameIndex("benannte")
        textIdx = provider.fieldNameIndex("text")
        if benannteIdx == -1 or textIdx == -1:
            print "VeriSO: Field not found!"
            return

        benannte =  str(feat.attributeMap()[benannteIdx].toString())
        lokalisationsname = feat.attributeMap()[textIdx].toString()
        
        # SQL von Achsen, Anfangspunkte, ben. Gebiete und Eingänge neu setzen.
        vlayerStrassenstueckLinie.setSubsetString("(gem_bfs = " +fosnr+ " AND los = " +lotnr+ " AND lieferdatum = '" +date+ "') AND (strassenstueck_von = '"+benannte+"')")
        vlayerStrassenstueckAnfangspunkt.setSubsetString("(gem_bfs = " +fosnr+ " AND los = " +lotnr+ " AND lieferdatum = '" +date+ "') AND (strassenstueck_von = '"+benannte+"')")
        vlayerBenanntesGebiet.setSubsetString("(gem_bfs = " +fosnr+ " AND los = " +lotnr+ " AND lieferdatum = '" +date+ "') AND (benanntesgebiet_von = '"+benannte+"')")
        vlayerEingaenge.setSubsetString("(gem_bfs = " +fosnr+ " AND los = " +lotnr+ " AND lieferdatum = '" +date+ "') AND (gebaeudeeingang_von = '"+benannte+"')")
        vlayerLokalisation.setSubsetString("(gem_bfs = " +fosnr+ " AND los = " +lotnr+ " AND lieferdatum = '" +date+ "') AND (tid = '"+benannte+"')")
        
        if vlayerStrassenstueckLinie.featureCount() > 0:
            xMin = vlayerStrassenstueckLinie.extent().xMinimum()
            yMin = vlayerStrassenstueckLinie.extent().yMinimum()
            xMax = vlayerStrassenstueckLinie.extent().xMaximum()
            yMax = vlayerStrassenstueckLinie.extent().yMaximum()
            
        if vlayerBenanntesGebiet.featureCount() > 0:
            xMin = vlayerBenanntesGebiet.extent().xMinimum()
            yMin = vlayerBenanntesGebiet.extent().yMinimum()
            xMax = vlayerBenanntesGebiet.extent().xMaximum()
            yMax = vlayerBenanntesGebiet.extent().yMaximum()
           
        try:
            if vlayerEingaenge.featureCount() > 0:
                if vlayerEingaenge.extent().xMinimum() < xMin:
                    xMin = vlayerEingaenge.extent().xMinimum()
                if vlayerEingaenge.extent().yMinimum() < yMin:
                    yMin = vlayerEingaenge.extent().yMinimum()
                if vlayerEingaenge.extent().xMaximum() > xMax:
                    xMax = vlayerEingaenge.extent().xMaximum()
                if vlayerEingaenge.extent().yMaximum() > yMax:
                    yMax = vlayerEingaenge.extent().yMaximum()                
                    
            rect = QgsRectangle(xMin,  yMin,  xMax,  yMax)
            rect.scale(1.3)
        
        except UnboundLocalError:
            vlayerGemeindegrenze = soverify.tools.utils.getVectorLayerByName("Gemeindegrenze")
            if vlayerGemeindegrenze == None:
                rect = self.canvas.fullExtent()
            else:
                rect = vlayerGemeindegrenze.extent()

        
        self.iface.mapCanvas().setExtent( rect )
        self.iface.mapCanvas().refresh()                

        # TextAnnotation:
        # Zuerst die Attribute der Lokalisation.
        
        provider = vlayerLokalisation.dataProvider()
        feat = QgsFeature()
        allAttrs = provider.attributeIndexes()
        provider.select(allAttrs, QgsRectangle(), False, False)        
        
        while provider.nextFeature(feat):
            prinzipIdx = provider.fieldNameIndex("nummerierungsprinzip_txt")
            attributeprovisorischIdx = provider.fieldNameIndex("attributeprovisorisch_txt")
            offiziellIdx = provider.fieldNameIndex("istoffiziellebezeichnung_txt")
            statusIdx = provider.fieldNameIndex("status_txt")
            inaenderungIdx = provider.fieldNameIndex("inaenderung_txt")
            artIdx = provider.fieldNameIndex("art_txt")
            
            
            if prinzipIdx == -1 or attributeprovisorischIdx == -1 or offiziellIdx == -1 or statusIdx == -1 or inaenderungIdx == -1 or artIdx == -1:
                print "VeriSO: Field not found!"
                return
            prinzip =  str(feat.attributeMap()[prinzipIdx].toString())
            attributeprovisorisch = feat.attributeMap()[attributeprovisorischIdx].toString()                
            offiziell = feat.attributeMap()[offiziellIdx].toString()
            status = feat.attributeMap()[statusIdx].toString()
            inaenderung = feat.attributeMap()[inaenderungIdx].toString()
            art = feat.attributeMap()[artIdx].toString()

        
        mapextent = self.canvas.extent()
        x = mapextent.xMinimum()
        y = mapextent.yMaximum()
        
        textItemFound = False
        items = self.iface.mapCanvas().scene().items()
        for i in range (len(items)):
#            print items[i]
            try:
                name =  items[i].data(0)
                if name.toString() == "LokalisationsInfo":
                    self.textItem = items[i]
                    textItemFound = True
            except:
                print "VeriSO: item.data(0) error"
        
        if textItemFound == False:
            self.textItem = QgsTextAnnotationItem( self.canvas )
            self.textItem.setData(0,  QVariant("LokalisationsInfo"))
        self.textItem.setMapPosition(QgsPoint(x+10*self.canvas.mapUnitsPerPixel(), y-10*self.canvas.mapUnitsPerPixel()))
        self.textItem.setMapPositionFixed(False)
        self.textItem.setFrameBorderWidth(0.0)   
        self.textItem.setFrameColor(QColor(250, 250, 250, 255))
        self.textItem.setFrameBackgroundColor(QColor(250, 250, 250, 120))
        self.textItem.setFrameSize(QSizeF(250,150))
        textDocument = QTextDocument()
        textDocument.setHtml("<table style='font-size:12px;'><tr><td>Lok.Name: </td><td>"+lokalisationsname+"</td></tr><tr><td>TID: </td><td>"+benannte+"</td></tr> <tr><td>Num.prinzip: </td><td>"+prinzip+"</td></tr> <tr><td>Attr. prov.: </td><td>"+attributeprovisorisch+"</td></tr> <tr><td>ist offiziell: </td><td>"+offiziell+"</td></tr> <tr><td>Status: </td><td>"+status+"</td></tr> <tr><td>in Aenderung: </td><td>"+inaenderung+"</td></tr> <tr><td>Art: </td><td>"+art+"</td></tr>  </table>")
        self.textItem.setDocument(textDocument)
#        self.textItem.update()        
#        self.iface.mapCanvas().refresh()          
        
        # Workaround: das erste Mal passt die Position nicht...???
        self.textItem.setMapPosition(QgsPoint(x+10*self.canvas.mapUnitsPerPixel(), y-10*self.canvas.mapUnitsPerPixel()))        
        self.textItem.update()               

        self.iface.mapCanvas().refresh()          
        
        # Das naechste Feature selektieren.
        try:
            vlayerLokalisationsName.setSelectedFeatures([ids[idx+1]])
        except IndexError:
            print "VeriSO: Ende der Tabelle."

        

        
        

