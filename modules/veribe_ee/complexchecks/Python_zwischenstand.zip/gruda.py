 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group5 = "Fixpunkte" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        group1 = "Plan und Nomenklatur" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        group2 = "BB/EO" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        group3 = "Liegenschaften" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        group4 = "Adressen" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Bodenbedeckung"
            layer["readonly"] = True 
            layer["featuretype"] = "bodenbedeckung_boflaeche"
            layer["geom"] = "geometrie"
            layer["sql"] = ""
            layer["group"] = group2
            layer["style"] = "bodenbedeckung/bb_"+_locale+".qml"
            vlayerBB = self.layerLoader.load(layer)


            layer = {}
            layer["title"] = "BEGID (BB)"
            layer["readonly"] = True
            layer["featuretype"] = "z_gebaeudenummer_pos"
            layer["key"] = "ogc_fid"
            layer["group"] = group2
            layer["geom"] = "pos"
            layer["sql"] = ""
            layer["style"] = "gebaeudeadressen/BEGIDeo_"+_locale+".qml"
            vlayerBBGID = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
  
            layer = {}
            layer["title"] = "BEGID (EO)"
            layer["readonly"] = True
            layer["featuretype"] = "z_objektnummer_pos"
            layer["key"] = "ogc_fid"
            layer["group"] = group2
            layer["geom"] = "pos"
            layer["sql"] = ""
            layer["style"] = "gebaeudeadressen/BEGIDeo_"+_locale+".qml"
            vlayerEOBEGID = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)


            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Plangeometrie"
            layer["readonly"] = True 
            layer["featuretype"] = "planeinteilungen_plan_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group1
            layer["style"] = "planeinteilung/plangeometrie_"+_locale+".qml"
            vlayerPlangeometrie = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False,  True)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Flurnamen"
            layer["readonly"] = True 
            layer["featuretype"] = "nomenklatur_flurname"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group1
            layer["style"] = "nomenklatur/nomenklatur_"+_locale+".qml"
            vlayerFlurname = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False,  True)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "PlanPos"
            layer["readonly"] = True
            layer["featuretype"] = "planeinteilungen_planpos_v"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group1
            layer["style"] = "planeinteilung/planpos_"+_locale+".qml"
            vlayerPlanPos = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False,  True)  
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Gemeindegrenze"
            layer["readonly"] = True 
            layer["featuretype"] = "gemeindegrenzen_gemeindegrenze"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group3
            layer["style"] = "gemeindegrenze/gemeindegrenze_"+_locale+".qml"
            vlayerGemeinde = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  True)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Grundstueck"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_grundstueck"
            layer["geom"] = ""
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group3
            vlayerGSTab = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "proj. SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_projselbstrecht"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group3
            layer["style"] = "liegenschaften/projselbstrecht_"+_locale+".qml"
            vlayerprojSDR = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "SDR"
            layer["readonly"] = True
            layer["featuretype"] = "liegenschaften_selbstrecht"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group3
            layer["style"] = "liegenschaften/selbstrecht_"+_locale+".qml"
            vlayer2SDR = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  True) 

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "proj. Liegenschaften"
            layer["readonly"] = True
            layer["featuretype"] = "liegenschaften_projliegenschaft"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["group"] = group3
            layer["sql"] = ""
            layer["style"] = "liegenschaften/projliegenschaft_"+_locale+".qml"
            vlayerprojLS = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Liegenschaften"
            layer["readonly"] = True
            layer["featuretype"] = "liegenschaften_liegenschaft"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["group"] = group3
            layer["sql"] = ""
            layer["style"] = "liegenschaften/liegenschaft_"+_locale+".qml"
            vlayerLS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False,  True)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Hilfslinie"
            layer["readonly"] = True
            layer["featuretype"] = "liegenschaften_grundstueckpos"
            layer["geom"] = "hilfslinie"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group3
            layer["style"] = "liegenschaften/hilfslinie_"+_locale+".qml"
            vlayerHilfe = self.layerLoader.load(layer)	

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "proj_Grst-Nr"
            layer["readonly"] = True
            layer["featuretype"] = "z_projgs_nr"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group3
            layer["style"] = "liegenschaften/proj_GS_NR_"+_locale+".qml"
            vlayerprojNrLS = self.layerLoader.load(layer)	

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Nr Gs(LS)"
            layer["readonly"] = True
            layer["featuretype"] = "z_nr_gs"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"
            layer["sql"] = "(art=0) and (gesamteflaechenmass is NULL)"
            layer["group"] = group3
            layer["style"] = "liegenschaften/nr_ls_ganz_"+_locale+".qml"
            vlayerNrGS = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Nr Gs(SDR)"
            layer["readonly"] = True
            layer["featuretype"] = "z_nr_gs"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"
            layer["group"] = group3
            layer["sql"] = "(art>0) and (gesamteflaechenmass is NULL)"
            layer["style"] = "liegenschaften/nr_sdr_ganz_"+_locale+".qml"
            vlayerNRGSSDR = self.layerLoader.load(layer) 

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Nr Gs(LS-Teil)"
            layer["readonly"] = True
            layer["featuretype"] = "z_nr_gs"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"
            layer["sql"] = "(art=0) and (gesamteflaechenmass>0)"
            layer["group"] = group3
            layer["style"] = "liegenschaften/nr_ls_teil_"+_locale+".qml"
            vlayerNTGSTeil = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Nr Gs(SDR Teil)"
            layer["readonly"] = True
            layer["featuretype"] = "z_nr_gs"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"
            layer["sql"] = "(art>0) and (gesamteflaechenmass>0)"
            layer["group"] = group3
            layer["style"] = "liegenschaften/nr_sdr_teil_"+_locale+".qml"
            vlayerGSRNSDRTeil = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"unvollstaendige Liegenschaften"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_liegenschaft_v2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Vollstaendigkeit=1"
            layer["group"] = group3
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerunvollLS = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "streitige SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_selbstrecht_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Gueltigkeit=1"
            layer["group"] = group3
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerstreitigSDR = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"unvollstaendige SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_selbstrecht_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Vollstaendigkeit=1"
            layer["group"] = group3
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerunvollSDR = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Linienart unvollstaendige SDR"
            layer["readonly"] = True 
            layer["featuretype"] = "z_lineatt_sdr"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Linienart is NULL"
            layer["group"] = group3
            layer["style"] = "liegenschaften/voll_streitig_"+_locale+".qml"
            vlayerLunvollSDR = self.layerLoader.load(layer)
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "streitige Liegenschaften"
            layer["readonly"] = True 
            layer["featuretype"] = "liegenschaften_liegenschaft_v2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "Gueltigkeit=1"
            layer["group"] = group3
            layer["style"] = "liegenschaften/voll_ls_"+_locale+".qml"
            vlayerstreitigLS = self.layerLoader.load(layer)

            

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "PLZ"
            layer["readonly"] = True 
            layer["featuretype"] = "plzortschaft_plz6"
            layer["geom"] = "flaeche"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/plz_"+_locale+".qml"
            vlayerPLZ = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Ortschaften"
            layer["readonly"] = True 
            layer["featuretype"] = "z_ortschaftsnamen_geom"
            layer["geom"] = "flaeche"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/ortschaft_"+_locale+".qml"
            vlayerortschaft = self.layerLoader.load(layer)
 

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "benanntes Gebiet"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_benanntesgebiet"
            layer["geom"] = "flaeche"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/benanntesGebiet_"+_locale+".qml"
            vlayerGeb = self.layerLoader.load(layer)


            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "proj. Gebaeude"
            layer["readonly"] = True 
            layer["featuretype"] = "bodenbedeckung_projboflaeche"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"
            layer["sql"] = "art = 0"
            layer["group"] = group4
            layer["style"] = "bodenbedeckung/projGebaeude_"+_locale+".qml"
            vlayerprojGeb = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "adressierbare EOs"
            layer["readonly"] = True 
            layer["featuretype"] = "z_eo_flaeche"
            layer["geom"] = "geometrie"
            layer["key"] = "ctid"
            layer["sql"] = "art in (1,2,6,11)"
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/EO_Gebaeude_"+_locale+".qml"
            vlayerEO = self.layerLoader.load(layer)

            layer = {}
            layer["title"] = "Strassenstueck Anfangspunkt"
            layer["readonly"] = True
            layer["featuretype"] = "gebaeudeadressen_strassenstueck"
            layer["geom"] = "anfangspunkt"
            layer["group"] = group4
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["style"] = "gebaeudeadressen/Anfangspunkt_"+_locale+".qml"
            vlayerStrasseA = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)

            layer = {}
            layer["title"] = "Strassenstueck (Geometrie)"
            layer["readonly"] = True
            layer["featuretype"] = "gebaeudeadressen_strassenstueck"
            layer["geom"] = "geometrie"
            layer["group"] = group4
            layer["sql"] = ""
            layer["key"] = "ogc_fid"
            layer["style"] = "gebaeudeadressen/strassenachsen_Pfeil_"+_locale+".qml"
            vlayerStrasse = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
    

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Spinnennetz"
            layer["readonly"] = True 
            layer["featuretype"] = "spiderweb_v"
            layer["geom"] = "line"
            layer["key"] = "ogc_fid"
            layer["sql"] = ""
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/spinnennetz_blau_"+_locale+".qml"
            vlayerSpinnen = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Gebaeudeeingang BB/EO"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_gebaeudeeingang"
            layer["geom"] = "lage"
            layer["key"] = "ogc_fid"
            layer["sql"] = "art in (1,2,6,11)"
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/GebEingang_BB_EO_"+_locale+".qml"  
            vlayerGebein = self.layerLoader.load(layer)
 
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LokalisationsNamePos"
            layer["readonly"] = True 
            layer["featuretype"] = "gebaeudeadressen_lokalisationsnamepos_v"
            layer["geom"] = "pos"
            layer["key"] = "ogc_fid"
            layer["sql"] = "art in (1,2,6,11)"
            layer["group"] = group4
            layer["style"] = "gebaeudeadressen/lokalisationsnamepos_"+_locale+".qml"   
            vlayerLokPos = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP2"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie2_lfp2"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group5        
            layer["style"] = "fixpunkte/lfp2_"+_locale+".qml"
            vlayerLFP2 = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP1"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie1_lfp1"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group5      
            layer["style"] = "fixpunkte/lfp1_"+_locale+".qml"
            vlayerLFP1 = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "LFP1 ausserhalb Gemeinde"
            layer["readonly"] = True 
            layer["featuretype"] = "fixpunktekategorie1_lfp1_ausserhalb_gemeinde_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group5       
            layer["style"] = "fixpunkte/lfp1ausserhalb_"+_locale+".qml"
            vlayerLFP1ausserhalb = self.layerLoader.load(layer)


             
            QApplication.restoreOverrideCursor()


        except:        
            QApplication.restoreOverrideCursor()

