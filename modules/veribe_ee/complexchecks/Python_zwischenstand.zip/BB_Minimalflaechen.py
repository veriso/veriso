 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group = "BB Minimalflaechen" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Toleranzstufen"
            layer["readonly"] = True 
            layer["featuretype"] = "tseinteilung_toleranzstufe"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/TS_"+_locale+".qml"
            vlayerTS = self.layerLoader.load(layer)
 
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Bodenbedeckungskanten"
            layer["readonly"] = True 
            layer["featuretype"] = "bodenbedeckung_boflaeche"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "bodenbedeckung/bb_kante_"+_locale+".qml"
            vlayerBB = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  True,  True)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"BB-Flächen TS4/TS5 kleiner 2500qm"
            layer["readonly"] = True 
            layer["featuretype"] = "z_v_bb_ts"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "ts_art in(3,4) and bb_art not in (0,3,6,15) and flaeche < 2500"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerTS45min = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"BB-Flächen TS3 kleiner 1000qm"
            layer["readonly"] = True 
            layer["featuretype"] = "z_v_bb_ts"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "ts_art=2 and bb_art not in (0,3,6,15) and flaeche < 1000"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerTS3min = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"BB-Flächen TS1/TS2 kleiner 100qm"
            layer["readonly"] = True 
            layer["featuretype"] = "z_v_bb_ts"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "ts_art in (0,1) and bb_art not in (0,3,6,15) and flaeche < 100"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerTS12min = self.layerLoader.load(layer)
           
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Wald kleiner 800qm"
            layer["readonly"] = True 
            layer["featuretype"] = "bodenbedeckung_boflaeche"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "art in(17,18,19,20) AND st_area(geometrie) < 800"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerWald = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"Gebäude kleiner 12qm"
            layer["readonly"] = True 
            layer["featuretype"] = "bodenbedeckung_boflaeche"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "art in(0) AND st_area(geometrie) < 12"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerGeb = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "Wasserbecken kleiner 20qm"
            layer["readonly"] = True 
            layer["featuretype"] = "bodenbedeckung_boflaeche"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "art in (6) AND st_area(geometrie) < 20"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerWb = self.layerLoader.load(layer)

            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"BB-Flächen kleiner 10qm pro LS"
            layer["readonly"] = True 
            layer["featuretype"] = "z_v_bb_ls"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "art<26 and art>0 AND flaeche>.6 and flaeche <10"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerBB = self.layerLoader.load(layer)

            TS1 = vlayerTS12min.featureCount()
            TS3 = vlayerTS3min.featureCount()
            TS4 = vlayerTS45min.featureCount()
            Geb = vlayerGeb.featureCount()
            Wb = vlayerWb.featureCount()
            Wald = vlayerWald.featureCount()
            BB = vlayerBB.featureCount()

            QMessageBox.information( None, "Minimalflaechen", "<b>Flaechen unterhalb Flaechenkriterien:</b> <br>" 
                                    + "<table>" 
				    + "<tr> <td>BB pro LS (10qm): </td> <td>" + str(BB) +  "</td> </tr>"
                                    + "<tr> <td>Wasserbecken (20qm): </td> <td>" + str(Wb) +  "</td> </tr>"                                + "<tr> <td>Gebaeude (12qm): </td> <td>" + str(Geb) +  "</td> </tr>"                                + "<tr> <td>Wald (800qm): </td> <td>" + str(Wald) +  "</td> </tr>" 
                                    + "<tr> <td>TS 1/2  (100qm) : </td> <td>" + str(TS1) +  "</td> </tr>" 
                                    + "<tr> <td>TS 3 (1000qm): </td> <td>" + str(TS3) +  "</td> </tr>" 
                                    + "<tr> <td>TS 4/5 (2500qm): </td> <td>" + str(TS4) +  "</td> </tr>" 
                                    + "</table>")

        except:        
            QApplication.restoreOverrideCursor()
 
        QApplication.restoreOverrideCursor()       



#        eingangOhneLokalisation = vlayerEingangOhneLokalisation.featureCount()
#        lokalisationsNameOhneEingang = vlayerLokalisationsNameOhneEingang.featureCount()
#        strassenstueckLinieIstAchse = vlayerStrassenstueckLinieIstAchse.featureCount()
#
#        QMessageBox.information( None, "Statistik Einzelobjekte", "<b>Statistik Einzelobjekte:</b> <br>" 
#                                + "<table>" 
#                                + u"<tr> <td>Mast_Leitung als Fläche: </td> <td>" + str(mastLeitungFlaeche) +  "</td> </tr>" 
#                                + u"<tr> <td>schmaler_Weg als Fläche: </td> <td>" + str(schmalerWegFlaeche) +  "</td> </tr>" 
#                                + "<tr> <td>Fahrspur als Linie: </td> <td>" + str(fahrspurLinie) +  "</td> </tr>" 
#                                + "</table>")
