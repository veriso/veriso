 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group = u"EO Flächenkriterien" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = u"schmale bestockte Fläche > 800 qm"
            layer["readonly"] = True 
            layer["featuretype"] = "einzelobjekte_flaechenelement_v"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = "art=24 AND st_area(geometrie) > 800"
            layer["group"] = group
            layer["style"] = "bodenbedeckung/kleiner_wald_"+_locale+".qml"
            vlayerWald = self.layerLoader.load(layer)

            Wald = vlayerWald.featureCount()

            QMessageBox.information( None, "EO Flaechenkriterien", "<b>EO Flaechenkriterien:</b> <br>" 
                                    + "<table>" 
                                   + "<tr> <td>schmale bestockte Flaeche (>800 qm): </td> <td>" + str(Wald) +  "</td> </tr>" 
                                    + "</table>")

        except:        
            QApplication.restoreOverrideCursor()
 
        QApplication.restoreOverrideCursor()       



#        eingangOhneLokalisation = vlayerEingangOhneLokalisation.featureCount()
#        lokalisationsNameOhneEingang = vlayerLokalisationsNameOhneEingang.featureCount()
#        strassenstueckLinieIstAchse = vlayerStrassenstueckLinieIstAchse.featureCount()
#
#        QMessageBox.information( None, "Statistik Einzelobjekte", "<b>Statistik Einzelobjekte:</b> <br>" 
#                                + "<table>" 
#                                + u"<tr> <td>Mast_Leitung als Fläche: </td> <td>" + str(mastLeitungFlaeche) +  "</td> </tr>" 
#                                + u"<tr> <td>schmaler_Weg als Fläche: </td> <td>" + str(schmalerWegFlaeche) +  "</td> </tr>" 
#                                + "<tr> <td>Fahrspur als Linie: </td> <td>" + str(fahrspurLinie) +  "</td> </tr>" 
#                                + "</table>")
