 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os
 
class ComplexCheck( QObject ):
     
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
         
    def run( self ):       
        settings = soverify.tools.utils.getSettings()
 
        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return
 
        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
             
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
         
        tempdir = settings["tempdir"]       
         
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
         
        group = "Gemeindegrenzen" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"       
        groupWMS = "WMS Grenz5"     
         
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
         
        try:  
          layer = {} 
          layer["type"] = "wms"
          layer["title"] = "Gemeindegrenzen-GRENZ5"
          layer["url"] ="http://www.geoservice.apps.be.ch/geoservice/services/a4p/a4p_grenzenwms_d_fk_s/MapServer/WMSServer?"            
          layer["layers"] ="GEODB.GRENZ5_K5,GEODB.GRENZ5_VKRS5_B,GEODB.GRENZ5_VKRS5,GEODB.GRENZ5_G5_B,GEODB.GRENZ5_G5,GEODB.GRENZ5_S5"
          layer["format"] ="image/png"
          layer["group"] = groupWMS
          layer["crs"] ="EPSG:21781"
          layer["sql"] = ""
          layer["style"] = ""
          vlayerWMS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          
          layer = {}

          layer["title"] = "Kantonsgrenzsteine -> Baselayer"
          layer["readonly"] = True
          layer["featuretype"] = ""
          layer["geom"] = ""
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["sql"] = ""
          layer["style"] = ""
          vlayerKantongs = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Gemeinde"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_gemeindegrenze"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "gemeindegrenze/gemeindegrenze_"+_locale+".qml"
          vlayerGemeinde = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)   
          layer = {}

          layer["title"] = "Hoheitsgrenzpunkte unversichert"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_hoheitsgrenzpunkt"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = "punktzeichen=6"
          layer["style"] = "liegenschaften/GP_unver_"+_locale+".qml"
          vlayerHGSunver = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Hoheitsgrenzpunkte nicht exakt definiert"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_hoheitsgrenzpunkt"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = "exaktdefiniert=1"
          layer["style"] = "liegenschaften/GP_exakt_"+_locale+".qml"
          vlayernexaktdef = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Hoheitsgrenzpunkte (schoener Stein)"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_hoheitsgrenzpunkt"
          layer["geom"] = "geometrie"
          layer["key"] = "ogc_fid"
          layer["group"] = group
          layer["sql"] = "Hoheitsgrenzstein=0"
          layer["style"] = "liegenschaften/HP_schoen_"+_locale+".qml"
          vlayerschoenerStein = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Hoheitsgrenzpunkte Zuverlässigkeit"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_hoheitsgrenzpunkt"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/GP_zuv_"+_locale+".qml"
          vlayerHSzuv = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)
          layer = {}

          layer["title"] = "Hoheitsgrenzpunkte Genauigkeit"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_hoheitsgrenzpunkt"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/GP_gen_"+_locale+".qml"
          vlayerHSgenau = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)	

          layer = {}

          layer["title"] = "proj. Gemeindegrenze"
          layer["readonly"] = True
          layer["featuretype"] = "gemeindegrenzen_projgemeindegrenze"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/projliegenschaft_"+_locale+".qml"
          vlayerprojGemeindegrenz = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)

          layer = {}

          layer["title"] = "Liegenschaften"
          layer["readonly"] = True
          layer["featuretype"] = "liegenschaften_liegenschaft"
          layer["geom"] = "geometrie"
          layer["group"] = group
          layer["key"] = "ogc_fid"
          layer["sql"] = ""
          layer["style"] = "liegenschaften/ls_quali_"+_locale+".qml"
          vlayerLS = soverify.tools.utils.doShowSimpleLayer( self.iface,  table,  True,  settings,  False, False)

        except:       
            QApplication.restoreOverrideCursor()
  
        QApplication.restoreOverrideCursor()      
 

