 # -*- coding: utf8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
from soverify.tools.dbTools import DbObj
import soverify.tools.utils
import os


class ComplexCheck( QObject ):
    
    def __init__( self,  iface,  settings ):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        pass
        
    def run( self ):        
        settings = soverify.tools.utils.getSettings()

        if settings["fosnr"] == "" or settings["lotnr"] == "" or settings["date"] == "" or settings["tempdir"] == "":
            QMessageBox.warning( None, "", "No workspace parameters or temp directory set.")
            return

        if settings["host"] == "" or settings["database"] == "" or settings["port"] == "" or settings["schema"] == "" or settings["username"] == "" or settings["password"] == "":
            QMessageBox.warning( None, "", "No database parameters set.")
            return
            
        fosnr = settings["fosnr"]
        lotnr = settings["lotnr"]
        date = settings["date"]
        
        tempdir = settings["tempdir"]        
        
        host = settings["host"]
        database = settings["database"]
        schema = settings["schema"]
        port =  settings["port"]
        username = settings["username"]
        password = settings["password"]
        
        group = "Grenzpunkt nicht auf Linie" + " (" + str(fosnr) + " / " + str(lotnr) + " / " + str(date) + ")"        
        
        #Change the cursor.
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:            
            layer = {}
            layer["type"] = "postgres"
            layer["title"] = "GP's ausserhalb Grenzlinien"
            layer["readonly"] = True 
            layer["featuretype"] = "z_grenzen"
            layer["geom"] = "geometrie"
            layer["key"] = "ogc_fid"            
            layer["sql"] = ""
            layer["group"] = group
            layer["style"] = "liegenschaften/GP_ausserhalb_"+_locale+".qml"
#            layer["style"] = "gebaeudeadressen/lokalisationsnamepos_newlabel_"+_locale+".qml"
            vlayerGP = self.layerLoader.load(layer)            
            
            GP = vlayerGP.featureCount()

            QMessageBox.information( None, "Statistik Fixpunkte", "<b>Grenzpunkte nicht auf Grenzlinie:</b> <br>" 
                                    + "<table>" 
                                    + "<tr> <td>Anzahl: </td> <td>" + str(GP) +  "</td> </tr>" 
                                    + "</table>")
  
#            layer = {}
#            layer["type"] = "wms"
#            layer["url"] = "http://wms.geo.admin.ch/"
#            layer["layers"] = "ch.bfs.gebaeude_wohnungs_register"
#            layer["crs"] = "EPSG:21781"
#            layer["format"] = "image/png"
#            layer["title"] = "GWR"
#            layer["group"] = group
#            vlayerGWR = self.layerLoader.load(layer)


            
        except:        
            QApplication.restoreOverrideCursor()
        
        QApplication.restoreOverrideCursor()


#        eingangOhneLokalisation = vlayerEingangOhneLokalisation.featureCount()
#        lokalisationsNameOhneEingang = vlayerLokalisationsNameOhneEingang.featureCount()
#        strassenstueckLinieIstAchse = vlayerStrassenstueckLinieIstAchse.featureCount()
#
#        QMessageBox.information( None, "Statistik Einzelobjekte", "<b>Statistik Einzelobjekte:</b> <br>" 
#                                + "<table>" 
#                                + u"<tr> <td>Mast_Leitung als Fläche: </td> <td>" + str(mastLeitungFlaeche) +  "</td> </tr>" 
#                                + u"<tr> <td>schmaler_Weg als Fläche: </td> <td>" + str(schmalerWegFlaeche) +  "</td> </tr>" 
#                                + "<tr> <td>Fahrspur als Linie: </td> <td>" + str(fahrspurLinie) +  "</td> </tr>" 
#                                + "</table>")
